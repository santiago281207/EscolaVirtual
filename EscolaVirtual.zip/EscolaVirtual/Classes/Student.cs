﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaVirtual.Classes
{
    public class Student : User
    {
        public Student(string password, string name, string schoolNumber, string nif, string email, string phoneNumber, string address, Class schoolClass) : base(password,name,nif,email,phoneNumber,address,UserRole.Student)
        {
            this.SchoolNumber = schoolNumber;
            this.Class = schoolClass;
            this.SchoolCard = new SchoolCard(0.0m,this);
        }

        #region Properties and Members

        private string m_schoolNumber;
        public string SchoolNumber
        {
            get { return m_schoolNumber; }
            set
            {
                if (value == null || value.Length != 6 || value.Any(c => c < '0' || c > '9'))
                    throw new ArgumentException("O número escolar deve conter exatamente 6 dígitos.", nameof(value));

                m_schoolNumber = value;
            }
        }

        private int m_absenceId;
        public int AbsenceId
        {
            get { return m_absenceId; }
            set { m_absenceId = value; }
        }

        private SchoolCard m_schoolCard;
        public SchoolCard SchoolCard
        {
            get { return m_schoolCard; }
            set { m_schoolCard = value; }
        }

        private Class m_class;
        public Class Class
        {
            get { return m_class; }
            set { m_class = value; }
        }

        private List<Grade> m_grades = new List<Grade>();
        public List<Grade> Grades
        {
            get { return m_grades; }
            set { m_grades = value; }
        }

        private List<Absence> m_absences = new List<Absence>();
        public List<Absence> Absence
        {
            get { return m_absences; }
            set { m_absences = value; }
        }




        #endregion

        



    }
}
